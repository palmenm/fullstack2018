const mongoose = require('mongoose')

// korvaa url oman tietokantasi urlilla. ethän laita salasanaa Githubiin!
const url = 'mongodb://fullstack:Lunagubbe1966@ds119663.mlab.com:19663/persons'

mongoose.connect(url,{ useNewUrlParser: true })
mongoose.Promise = global.Promise

const Person = mongoose.model('Person', {
  name: String,
  number: String,
  id: Number
})
  
module.exports = Person