const express = require('express')
const app = express()
const bodyParser = require('body-parser')
const morgan = require('morgan')
const cors = require('cors')
const Person = require('./models/person')

//request parser
app.use(bodyParser.json())

 app.use(morgan('tiny'));
 app.use(cors())
 app.use(express.static('build'))
 
 /*
 let persons = [
    {
      "name": "Arto Hellas",
      "number": "040-123456",
      "id": 1
    },
    {
      "name": "Martti Tienari",
      "number": "040-123456",
      "id": 2
    },
    {
      "name": "Arto Järvinen",
      "number": "040-123456",
      "id": 3
    },
    {
      "name": "Lea Kutvonen",
      "number": "040-123456",
      "id": 4
    }
  ]
 */
 const formatPerson = (person) => {
  return {
    name: person.name,
    number: person.number,
    id: person._id
  }
}

app.get('/info', (req, res) => {
  var size = persons.length; 	
  var d = new Date();
  res.send('<h3>Puhelinluettelossa '+size+' henkilön tiedot </h3>'+d)
})

app.get('/', (req, res) => {
  res.send('<h1>Hello World!</h1>')
})

app.get('/api/persons', (req, res) => {
    Person
    .find({})
    .then(pers => {
      res.json(pers.map(formatPerson))
    })	
 // res.json(persons)
})

app.get('/api/persons/:id', (req, res) => {
   const id = Number(req.params.id)	

   Person
    .findById(req.params.id)
    .then(pers => {
      res.json(formatNote(pers))
    })
    .catch(error => {
      console.log(error)
      res.status(404).end()
    })
	
   /*)	
   const person = persons.find(p => p.id === id )
   if ( person ) {
    res.json(person)
   } else {
    res.send('<h3>Henkilöä id:llä '+id+' ei löydy (404) </h3> ')
   }   
   */
})


app.post('/persons', (request, response) => { 
  const person2 = request.body
  console.log(person2.name)
  
  if (person2.name === undefined || person2.number === undefined) {
    return response.status(400).json({error: 'name or number is missing'})
  }
  
  const mId = Math.floor((Math.random() * 1000) + 1)
    
  const person = new Person({
		name: person2.name,
		number: person2.number,
		id:mId 
	 })	
  /*
  const person3 = persons.find(person => person.name === person2.name)
  if(person3){
	return response.status(400).json({error: 'name exists in the catalog'})  
  }
  */
  /*
  while(1){
	const mId = Math.floor((Math.random() * 1000) + 1)
	console.log(mId)
	const person = persons.find(person => person.id === mId)
	if(person){	  
	}	
	else{
	  person2.id = mId;
      break;		
	}
  }
  persons = persons.concat(person2)
  response.json(person2)
  */
 person
  .save()
  .then(response => {
    console.log('person saved!')
    mongoose.connection.close()
  })   
})


app.delete('/persons/:id', (request, response) => {
  
  Person
    .findByIdAndRemove(request.params.id)
    .then(result => {
      response.status(204).end()
    })
    .catch(error => {
      response.status(400).send({ error: 'malformatted id' })
    })
	
  /*
  persons = persons.filter(person => person.id !== id)
  response.status(204).end()
  */
})

const PORT = process.env.PORT || 3001
app.listen(PORT, () => {
  console.log('Server running on port ${PORT}')
})
