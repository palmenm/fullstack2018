const mongoose = require('mongoose')

// korvaa url oman tietokantasi urlilla. ethän laita salasanaa Githubiin!
const url = 'mongodb://fullstack:Lunagubbe1966@ds119663.mlab.com:19663/persons'

mongoose.connect(url,{ useNewUrlParser: true })

var name = process.argv[2];
var number = process.argv[3];
const mId = Math.floor((Math.random() * 1000) + 1)

const Person = mongoose.model('Person', {
  name: String,
  number: String,
  id: Number
})

console.log(' argumentteja '+process.argv.length)

if(process.argv.length == 4)
{
	console.log(' name '+name+', number '+number+', id '+mId)
	
  const person = new Person({
		name: name,
		number: number,
		id:mId 
	 })	
	
 person
  .save()
  .then(response => {
    console.log('person saved!')
    mongoose.connection.close()
  }) 
  console.log('lisätään henkilö '+name+' numero '+number+' luetteloon')
}
else{
 console.log('Puhelinluettelo:') 	
 Person
  .find({})
  .then(result => {
    result.forEach(person => {
      console.log(person.name+' '+person.number)
    })
    mongoose.connection.close()
  })	
}
