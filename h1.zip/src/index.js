import React from 'react'
import ReactDOM from 'react-dom'

const kurssi = 'Anna palautetta'
const teksti = 'Statistiikka'
const teksti2 = 'Ei yhtään palautetta annettu'

const Otsikko = ({ textx }) => {
  return (
    <h2>{textx}</h2>
  )
}



const Statistics = ({ counter, counter2, counter3 }) => {
  const a = counter
  const b = counter2
  const c = counter3
  var ka = 0
  var pos = 0
  
  if(a+b+c !== 0)
    ka = (a-c)/(a+b+c)
  if(a+b+c !== 0)
    pos = (a/(a+b+c))*100.0

  pos = pos +"%"
  
  if(a!==0 || b!==0 || c!==0)
  {
  return (
   <div>
    <Statistic actionvalue={counter} text="Hyvä"/>
	<Statistic actionvalue={counter2} text="Neutraali"/>
	<Statistic actionvalue={counter3} text="Huono" />
	<Statistic actionvalue={ka} text="Keskiarvo" />
	<Statistic actionvalue={pos} text="Positiivisia" />
   </div>
  )
  }
  else{
   return (
   <div>
	  <Statistic actionvalue="" text={teksti2} />
   </div>	)  
  }
}

const Statistic = ({ actionvalue, text }) => {
  return (
    <div>{text} {actionvalue}</div>
  )
}

const Button = ({ handleClick, text }) => (
  <button onClick={handleClick}>
    {text}
  </button>
)

class App extends React.Component {
  constructor() {
    super()
    this.state = {
      counter: 0, counter2: 0, counter3: 0
    }
  }

  asetaArvoon = (arvo) => {
    return () => {
      this.setState({ counter: arvo })
    }
  }

  asetaArvoon2 = (arvo) => {
    return () => {
      this.setState({ counter2: arvo })
    }
  }
  
  asetaArvoon3 = (arvo) => {
    return () => {
      this.setState({ counter3: arvo })
    }
  }
  
  
  
  render() {
    return (
      <div>
        <Otsikko textx={kurssi}/>
        <div>
		  <Button handleClick={this.asetaArvoon(this.state.counter + 1)} text="Hyvä"/>&nbsp;
		  <Button handleClick={this.asetaArvoon2(this.state.counter2 + 1)} text="Neutraali"/>&nbsp;
		  <Button handleClick={this.asetaArvoon3(this.state.counter3 + 1)} text="Huono"/>
        </div>
		<Otsikko textx={teksti}/>
		<Statistics counter={this.state.counter} counter2={this.state.counter2} counter3={this.state.counter3}/>
      </div>
    )
  }
}


ReactDOM.render(
  <App />,
  document.getElementById('root')
)