import React from 'react'
import ReactDOM from 'react-dom'

class App extends React.Component {
  constructor() {
    super()
    this.state = {
      counter: 0, counter2: 0, counter3: 0
    }
  }

  asetaArvoon = (arvo) => {
    return () => {
      this.setState({ counter: arvo })
    }
  }

  asetaArvoon2 = (arvo) => {
    return () => {
      this.setState({ counter2: arvo })
    }
  }
  
  asetaArvoon3 = (arvo) => {
    return () => {
      this.setState({ counter3: arvo })
    }
  }
  
  render() {
    return (
      <div>
        <h2>Anna palautetta</h2>
        <div>
          <button onClick={this.asetaArvoon(this.state.counter + 1)}>
            Hyvä
          </button>&nbsp;
          <button onClick={this.asetaArvoon2(this.state.counter2 + 1)}>
            Neutraali
          </button>&nbsp;	  
          <button onClick={this.asetaArvoon3(this.state.counter3 + 1)}>
            Huono
          </button>
        </div>
		<h2>Statistiikka</h2>
		<div>Hyvä {this.state.counter}</div>
		<div>Neutraali {this.state.counter2}</div>
		<div>Huono {this.state.counter3}</div>
      </div>
    )
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)