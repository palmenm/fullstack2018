import React from 'react'
import ReactDOM from 'react-dom'

class App extends React.Component {
  constructor() {
    super()
    this.state = {
      counter: 1, counter2: 0
    }
  }

  asetaArvoon = (arvo) => {
    return () => {
      this.setState({ counter: arvo })
    }
  }

  asetaArvoon2 = (arvo) => {
    return () => {
      this.setState({ counter2: arvo })
    }
  }
  
  render() {
    return (
      <div>
        <div>{this.state.counter}</div><div>{this.state.counter2}</div>
        <div>
          <button onClick={this.asetaArvoon(this.state.counter + 1)}>
            arvo1
          </button>
          <button onClick={this.asetaArvoon2(this.state.counter2 + 1)}>
            arvo2
          </button>		  
          <button onClick={this.asetaArvoon(0)}>
            Zero
          </button>
        </div>
      </div>
    )
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)