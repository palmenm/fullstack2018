import React from 'react'
import ReactDOM from 'react-dom'


const Otsikko = (props) => {
  return (
    <div>
      <h1>{props.kurssi.nimi}</h1>
    </div>
  )
}


const Osa = (props) => {
  return (
    <div>
      <p>{props.osa} {props.tehtavia}</p>
    </div>
  )
}

const Kurssi = (props) => {
	
  var  notes  = props.kurssi.osat;
  const rivit = () => notes.map(note => <li key={note.id}>{note.nimi}</li>)
  	
  return (
    <div>
	  <Otsikko kurssi={props.kurssi}/>
       <ul>
        {rivit()}
      </ul>
    </div>
  )
}

const Yhteensa = (props) => {
  var  notes  = props.kurssi.osat;
  return (
    <div>
      <p>yhteensä {props.kurssi.osat[0].tehtavia + props.kurssi.osat[1].tehtavia + props.kurssi.osat[2].tehtavia} tehtävää</p>
    </div>
  )
}

const App = () => {
  const kurssi = {
    nimi: 'Half Stack -sovelluskehitys',
    osat: [
      {
        nimi: 'Reactin perusteet',
        tehtavia: 10,
        id: 1
      },
      {
        nimi: 'Tiedonvälitys propseilla',
        tehtavia: 7,
        id: 2
      },
      {
        nimi: 'Komponenttien tila',
        tehtavia: 14,
        id: 3
      }

    ]
  }

  return (
    <div>
      <Kurssi kurssi={kurssi} />
    </div>
  )

  
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
