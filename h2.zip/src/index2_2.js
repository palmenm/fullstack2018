import React from 'react'
import ReactDOM from 'react-dom'


const Otsikko = (props) => {
  return (
    <div>
      <h1>{props.kurssi.nimi}</h1>
    </div>
  )
}


const Kurssi = (props) => {
	
  var  notes  = props.kurssi.osat;
  const rivit = () => notes.map(note => <li key={note.id}>{note.nimi}</li>)
 
  const yht = notes.reduce(function (accumulator, note) {
   return accumulator + note.tehtavia;
  }, 0);
  
  console.log(yht)
  return (
    <div>
	  <Otsikko kurssi={props.kurssi}/>
       <ul>
        {rivit()}
      </ul>
	  <Yhteensa val={yht}/>
    </div>
  )
}

const Yhteensa = (props) => {
  return (
    <div>
      <p>yhteensä {props.val} tehtävää</p>
    </div>
  )
}

const App = () => {
  const kurssi = {
    nimi: 'Half Stack -sovelluskehitys',
    osat: [
      {
        nimi: 'Reactin perusteet',
        tehtavia: 10,
        id: 1
      },
      {
        nimi: 'Tiedonvälitys propseilla',
        tehtavia: 7,
        id: 2
      },
      {
        nimi: 'Komponenttien tila',
        tehtavia: 14,
        id: 3
      },
      {
        nimi: 'kikkailua',
        tehtavia: 7,
        id: 4
      }	  
    ]
  }

  return (
    <div>
      <Kurssi kurssi={kurssi} />
    </div>
  )

  
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
