import React from 'react';
  
const Person2 = ({ person, toggleImportance }) => {
  return (
    <p> {person.name} {person.number} <button onClick={toggleImportance}>poista</button>
	</p> 
  )
}

export default Person2