import React from 'react'
import ReactDOM from 'react-dom'


const Otsikko = (props) => {
  return (
    <div>
      <h1>{props.kurssi.nimi}</h1>
    </div>
  )
}

const Kurssit = (props) => {
	
  var  notes  = props.kurssit;
  const rivit = () => notes.map(note => <Kurssi kurssi={note}/>)

  return(rivit())
}

const Kurssi = (props) => {
	
  var  notes  = props.kurssi.osat;
  const rivit = () => notes.map(note => <li key={note.id}>{note.nimi}</li>)
 
  const yht = notes.reduce(function (accumulator, note) {
   return accumulator + note.tehtavia;
  }, 0);
  
  console.log(yht)
  return (
    <div>
	  <Otsikko kurssi={props.kurssi}/>
       <ul>
        {rivit()}
      </ul>
	  <Yhteensa val={yht}/>
    </div>
  )
}

const Yhteensa = (props) => {
  return (
    <div>
      <p>yhteensä {props.val} tehtävää</p>
    </div>
  )
}

export default Kurssi